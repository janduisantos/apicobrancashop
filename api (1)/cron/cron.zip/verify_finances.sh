#!/bin/bash

DB_HOST="localhost"
DB_USER="faturabr"
DB_PASS="w7nmF2BB7hZxbm4j"
DB_NAME="faturabr"

while true; do
    # Obter os IDs dos registros duplicados
    duplicates=$(mysql -h $DB_HOST -u $DB_USER -p$DB_PASS $DB_NAME -e "
        SELECT GROUP_CONCAT(id) as ids
        FROM $DB_NAME.finances
        WHERE (client_id, data, tipo) IN (
            SELECT client_id, data, tipo
            FROM $DB_NAME.finances
            GROUP BY client_id, data, tipo
            HAVING COUNT(*) > 1
        )
    " | tail -n 1)

    if [ $? -eq 0 ]; then
        # Verificar se há registros duplicados
        if [ -n "$duplicates" ]; then
            # Excluir registros duplicados
            deleteQuery="DELETE FROM $DB_NAME.finances WHERE id IN ($duplicates)"
            mysql -h $DB_HOST -u $DB_USER -p$DB_PASS $DB_NAME -e "$deleteQuery"
        fi
    else
        echo "Erro ao executar a consulta."
    fi

    # Aguardar um intervalo de tempo antes de realizar a próxima verificação
    sleep 3
done
